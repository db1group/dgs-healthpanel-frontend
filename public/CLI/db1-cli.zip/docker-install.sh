#!/bin/sh

sh get-docker.sh
usermod -aG docker $USER
apt-get install docker-compose-plugin
docker --version
update-alternatives --config iptables