#!/bin/bash

echo "Bem-vindo ao DB1 CLI"

if [[ $EUID -ne 0 ]]; then
    echo "Este script precisa ser executado com privilégios de superusuário (sudo)." >&2
    exit 1
else
    while true; do
        echo ""
        echo "Menu:"
        echo "1. Instalar Docker"
        echo "2. Instalar Sonar"
        echo "3. Coletar Métricas para o Painel"
        echo "4. Sair"
        read -p "Escolha uma opção: " opcao

        case $opcao in
            1)
                echo "Instalando Docker..."
                sh docker-install.sh
                echo "Docker instalado com sucesso!"
                ;;
            2)
                echo "Instalando Sonar..."

                docker network create localcli

                if docker ps -a --format '{{.Names}}' | grep -q "SonarCLI"; then
                    docker container start SonarCLI
                    echo "Sonar iniciado com sucesso!"
                else
                    docker run --network=localcli -d -p 9000:9000 --name SonarCLI sonarqube:latest
                    echo "Sonar instalado com sucesso!"
                fi
                
                echo "Acesse http://localhost:9000, configure seu projeto e submeta para análise"
                ;;
            3)
                echo "Coletando Métricas para o Painel..."

                if docker ps -a --format '{{.Names}}' | grep -q "Db1MetricsCollector"; then
                    docker container start Db1MetricsCollector
                else
                    read -p "Informe o Sonar Token: " sonarToken

                    ip_address=$(docker network inspect localcli --format='{{range .Containers}}{{if eq .Name "SonarCLI"}}{{.IPv4Address}}{{end}}{{end}}')
                    ip_address=$(echo "$ip_address" | cut -d'/' -f1)

                    docker run --network=localcli -d -p 8000:8000 -e SONAR_TOKEN=$sonarToken -e SONAR_URL=$ip_address --name Db1MetricsCollector erickantunes/db1-metrics-collector:latest
                fi
                echo "Métricas coletadas com sucesso!"
                ;;
            4)
                echo "Saindo..."
                break
                ;;
            *)
                echo "Opção inválida. Tente novamente."
                ;;
        esac
    done
fi
