# Introdução
Ambos os prompts requerem Administrador

Se você usa windows abra o terminal powershell e execute o ./db1-cli-win.ps1
Se você usa linux abra o terminal e execute ./db1-cli.sh
