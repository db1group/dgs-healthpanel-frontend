$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $isAdmin) {
    Write-Host "Este script precisa ser executado como administrador."
    exit
}

Write-Host "Bem-vindo ao DB1 CLI"

do {
    Write-Host "`nMenu:"
    Write-Host "1. Instalar/Atualizar o WSL2"
    Write-Host "2. Instalar o Ubuntu 22.04"
    Write-Host "3. Iniciar o Sonar"
    Write-Host "4. Coletar Métricas para o Painel"
    Write-Host "5. Sair"

    $opcao = Read-Host "Escolha uma opção"

    switch ($opcao) {
        1 {
            Write-Host "Instalando o WSL2..."
            dism.exe /online /enable-feature /featurename:Microsoft-Windows-Subsystem-Linux /all /norestart
            dism.exe /online /enable-feature /featurename:VirtualMachinePlatform /all /norestart
            Enable-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V -Al
            wsl --set-default-version 2
            wsl --update
            Write-Host "WSL2 instalado com sucesso!"
            break
        }
        2 {
            $wslListOutput = wsl --list --quiet
              
            if ($wslListOutput -contains "Ubuntu-22.04") {
                Write-Host "Ubuntu 22.04 já está instalado"    
            } else {
                Write-Host "Instalando o Ubuntu 22.04..."
                Write-Host "Após a instalação, insira seu usuário e senha, após entrar no terminal do Ubuntu digite exit e selecione outra opção."
                wsl --unregister ubuntu-22.04
                wsl --install -d ubuntu-22.04
                Write-Host "Ubuntu 22.04 instalado com sucesso!"
            }
            break
        }
        3 {
            Write-Host "Iniciando o Sonar..."
            $command = "-u root -d Ubuntu-22.04 --exec apt update"
            Start-Process -FilePath "wsl" -ArgumentList $command -Wait -NoNewWindow

            $command = "-u root -d Ubuntu-22.04 --exec apt upgrade -y"
            Start-Process -FilePath "wsl" -ArgumentList $command -Wait -NoNewWindow

            $command = "wsl -d Ubuntu-22.04 --exec dpkg -s docker-ce"
            $output = (Invoke-Expression -Command $command) 2>&1
            
            if ($output -match "Status: install ok installed") {
                Write-Host "Docker já instalado"
            } else {
                $scriptPath = "docker-install.sh"

                $command = "-u root -d Ubuntu-22.04 --exec bash $scriptPath"
                Start-Process -FilePath "wsl" -ArgumentList $command -Wait -NoNewWindow
            }

            $command = "-u root -d Ubuntu-22.04 --exec docker network create localcli"
            Start-Process -FilePath "wsl" -ArgumentList $command -Wait -NoNewWindow
            
            $command = "wsl -u root -d Ubuntu-22.04 --exec docker ps -a --format '{{.Names}}'"
            $output = (Invoke-Expression -Command $command) 2>&1
            
            if ($output -contains "SonarCLI") {
                Write-Host "Sonar já existe"
                $command = "-u root -d Ubuntu-22.04 --exec docker container start SonarCLI"
                Start-Process -FilePath "wsl" -ArgumentList $command -Wait -NoNewWindow
            } else {
                $SonarToken = Read-Host "Digite o Sonar Token"
                $command = "-u root -d Ubuntu-22.04 --exec docker run --network=localcli -d -p 9000:9000 -e SONAR_TOKEN=$SonarToken --name SonarCLI sonarqube:latest"
                Start-Process -FilePath "wsl" -ArgumentList $command -Wait -NoNewWindow
            }
            
            Write-Host "Sonar iniciado com sucesso!"
            Write-Host "Acesse http://localhost:9000, configure seu projeto e submeta para análise"
            break
        }
        4 {
            Write-Host "Coletando as métricas..."            
            $command = "wsl -u root -d Ubuntu-22.04 --exec docker ps --format '{{.Names}}'"
            $output = (Invoke-Expression -Command $command) 2>&1
            
            if ($output -contains "Db1MetricsCollector") {
                Write-Host "Db1MetricsCollector já existe"
                $command = "-u root -d Ubuntu-22.04 --exec docker container start Db1MetricsCollector"
                Start-Process -FilePath "wsl" -ArgumentList $command -Wait -NoNewWindow
            } else {
                $command = "-u root -d Ubuntu-22.04 --exec docker run --network=localcli -d -p 8000:8000 --name Db1MetricsCollector erickantunes/db1-metrics-collector:latest"
                Start-Process -FilePath "wsl" -ArgumentList $command -Wait -NoNewWindow
            }
            
            Write-Host "Métricas coletadas com sucesso!"
            break
        }
        5 {
            break
        }
        default {
            Write-Host "Opção inválida. Tente novamente."
        }
    }
} while ($opcao -ne "5")
